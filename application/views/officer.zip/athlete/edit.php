<div class="content-wrapper">
 <section class="content" style="min-height: 526px;">
            <div class="col-xs-12">
            <div class="col-lg-12 col-sm-12 col-xs-12 no-padding"><h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1></div>
            </div>
  
  
    
    <!-- Back Button -->
    <div class="mb-3">
        <a href="<?php echo site_url('athlete'); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
        
    </div>
    
 <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="box box-primary">


        <!-- Flash Messages -->
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle mr-2"></i>
                <?php echo $this->session->flashdata('success'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?php echo $this->session->flashdata('error'); ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <!-- Edit Form Card -->
         <div class="box-header with-border">

<div class="callout callout-info">
         <h4  class="box-title">Edit Athlete Information</h4>
         
          
        </div> 
       
           
            <div class="card-body">
                <?php echo form_open_multipart('athlete/update/' . $athlete['id']); ?>
                
                <!-- Hidden field for old photo -->
                <input type="hidden" name="old_photo" value="<?php echo $athlete['photo']; ?>">
                
                <!-- Validation Errors -->
                <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>
                
                <div class="row">
                    <!-- Left Column -->
                    <div class="col-md-6">
                        <!-- Full Name -->
                        <div class="form-group">
                            <label for="full_name" class="font-weight-bold">Full Name *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="full_name" 
                                   name="full_name" 
                                   value="<?php echo set_value('full_name', $athlete['full_name']); ?>" 
                                   required>
                        </div>

                        <!-- Sex -->
                        <div class="form-group">
                            <label for="sex" class="font-weight-bold">Sex *</label>
                            <select class="form-control" id="sex" name="sex" required>
                                <option value="">Select Sex</option>
                                <option value="Male" <?php echo set_select('sex', 'Male', $athlete['sex'] == 'Male'); ?>>Male</option>
                                <option value="Female" <?php echo set_select('sex', 'Female', $athlete['sex'] == 'Female'); ?>>Female</option>
                                <option value="Other" <?php echo set_select('sex', 'Other', $athlete['sex'] == 'Other'); ?>>Other</option>
                            </select>
                        </div>

                        <!-- Age -->
                        <div class="form-group">
                            <label for="age" class="font-weight-bold">Age *</label>
                            <input type="number" 
                                   class="form-control" 
                                   id="age" 
                                   name="age" 
                                   value="<?php echo set_value('age', $athlete['age']); ?>" 
                                   min="13" 
                                   max="59" 
                                   required>
                            <small class="form-text text-muted">Age must be between 13 and 59</small>
                        </div>

                        <!-- Region -->
                        <div class="form-group">
                            <label for="region" class="font-weight-bold">Region *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="region" 
                                   name="region" 
                                   value="<?php echo set_value('region', $athlete['region']); ?>" 
                                   required>
                        </div>
                    </div>

                    <!-- Right Column -->
                    <div class="col-md-6">
                        <!-- Sport -->
                        <div class="form-group">
                            <label for="sport" class="font-weight-bold">Sport *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="sport" 
                                   name="sport" 
                                   value="<?php echo set_value('sport', $athlete['sport']); ?>" 
                                   required>
                        </div>

                        <!-- Current Photo -->
                        <div class="form-group">
                            <label class="font-weight-bold">Current Photo</label>
                            <div class="text-center">
                                <?php if (!empty($athlete['photo']) && file_exists(FCPATH . 'uploads/athletes/' . $athlete['photo'])): ?>
                                    <img src="<?php echo base_url('uploads/athletes/' . $athlete['photo']); ?>" 
                                         alt="<?php echo htmlspecialchars($athlete['full_name']); ?>" 
                                         class="rounded-circle img-thumbnail mb-2"
                                         style="width: 150px; height: 150px; object-fit: cover;">
                                    <p class="small text-muted"><?php echo $athlete['photo']; ?></p>
                                <?php else: ?>
                                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center bg-light mb-2"
                                         style="width: 150px; height: 150px; border: 2px solid #dee2e6;">
                                        <i class="fas fa-user fa-3x text-muted"></i>
                                    </div>
                                    <p class="small text-muted">No photo uploaded</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- New Photo Upload -->
                        <div class="form-group">
                            <label for="photo" class="font-weight-bold">Update Photo</label>
                            <div class="custom-file">
                                <input type="file" 
                                       class="custom-file-input" 
                                       id="photo" 
                                       name="photo" 
                                       accept="image/*">
                                <label class="custom-file-label" for="photo">Choose new photo (optional)</label>
                            </div>
                            <small class="form-text text-muted">Leave empty to keep current photo. Allowed types: JPG, PNG, GIF. Max size: 2MB</small>
                            
                            <!-- New Photo Preview -->
                            <div class="mt-3 text-center" id="photoPreview" style="display: none;">
                                <p class="small text-muted mb-2">New Photo Preview:</p>
                                <img id="previewImage" src="" alt="Preview" 
                                     class="img-thumbnail"
                                     style="max-width: 150px; max-height: 150px;">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="form-group mt-4 pt-3 border-top">
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="fas fa-save mr-1"></i> Update Athlete
                        </button>
                        <a href="<?php echo site_url('athlete'); ?>" class="btn btn-secondary px-4 ml-2">
                            <i class="fas fa-times mr-1"></i> Cancel
                        </a>
                        <a href="<?php echo site_url('athlete/delete/' . $athlete['id']); ?>" 
                           class="btn btn-danger px-4 ml-2"
                           onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars(addslashes($athlete['full_name'])); ?>?')">
                            <i class="fas fa-trash mr-1"></i> Delete
                        </a>
                    </div>
                </div>
                
                <?php echo form_close(); ?>
           </div>
       </div>
   </div>
</div>
</section>
</div>

<script>
$(document).ready(function() {
    // Preview uploaded image
    $('#photo').on('change', function(e) {
        var file = e.target.files[0];
        var preview = $('#previewImage');
        var previewDiv = $('#photoPreview');
        var fileLabel = $(this).next('.custom-file-label');
        
        if (file) {
            // Check file size (2MB = 2097152 bytes)
            if (file.size > 2097152) {
                alert('File size must be less than 2MB');
                this.value = '';
                fileLabel.text('Choose new photo (optional)');
                previewDiv.hide();
                return;
            }
            
            // Check file type
            var validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
            if (!validTypes.includes(file.type)) {
                alert('Only JPG, PNG, and GIF files are allowed');
                this.value = '';
                fileLabel.text('Choose new photo (optional)');
                previewDiv.hide();
                return;
            }
            
            var reader = new FileReader();
            reader.onload = function(e) {
                preview.attr('src', e.target.result);
                previewDiv.show();
            }
            reader.readAsDataURL(file);
            
            // Update file label
            var fileName = file.name.length > 25 ? file.name.substring(0, 25) + '...' : file.name;
            fileLabel.text(fileName);
        } else {
            previewDiv.hide();
            fileLabel.text('Choose new photo (optional)');
        }
    });
    
    // Update custom file label on change
    $('.custom-file-input').on('change', function() {
        var fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });
});
</script>

<style>
    .content-wrapper {
        background-color: #f8f9fc;
    }
    
    .card {
        border: none;
        border-radius: 8px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
    }
    
    .card-header {
        background-color: white;
        border-bottom: 1px solid #e3e6f0;
        padding: 1rem 1.35rem;
    }
    
    .form-control {
        border-radius: 4px;
        border: 1px solid #d1d3e2;
        padding: 0.5rem 0.75rem;
    }
    
    .form-control:focus {
        border-color: #4e73df;
        box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
    }
    
    label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 0.5rem;
    }
    
    .custom-file-label {
        border-radius: 4px;
        border: 1px solid #d1d3e2;
    }
    
    .custom-file-input:focus ~ .custom-file-label {
        border-color: #4e73df;
        box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
    }
    
    .img-thumbnail {
        border: 1px solid #e3e6f0;
        padding: 4px;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .card-body {
            padding: 1.5rem !important;
        }
        
        .btn {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
        
        .btn + .btn {
            margin-left: 0;
        }
    }
</style>