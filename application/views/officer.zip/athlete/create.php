<div class="content-wrapper">
 <section class="content" style="min-height: 526px;">
            <div class="col-xs-12">
            <div class="col-lg-12 col-sm-12 col-xs-12 no-padding"><h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1></div>
            </div>
  
  
    
    <!-- Back Button -->
    <div class="mb-3">
        <a href="<?php echo site_url('athlete'); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
        
    </div>
    
 <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="box box-primary">

    <!-- Form -->
    <div class="card shadow mb-4">
        
        <div class="card-body">
            <?php echo form_open_multipart('athlete/create'); ?>
            
                <!-- Validation Errors -->
                <?php if (validation_errors()): ?>
                    <div class="alert alert-danger">
                        <?php echo validation_errors(); ?>
                    </div>
                <?php endif; ?>
               <div class="box-header with-border">

<div class="callout callout-info">
         <h4  class="box-title">Athlete Information</h4>
         
          
        </div> 
                <div class="row">
                    <div class="col-md-6">
                        <!-- Full Name -->
                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" 
                                   class="form-control" 

                                   id="full_name" 
                                   name="full_name" 
                                   value="<?php echo set_value('full_name'); ?>" 
                                   required>
                        </div>
                        
                        <!-- Sex -->
                        <div class="form-group">
                            <label for="sex">Sex *</label>
                            <select class="form-control" id="sex" name="sex" required>
                                <option value="">Select Sex</option>
                                <option value="Male" <?php echo set_select('sex', 'Male'); ?>>Male</option>
                                <option value="Female" <?php echo set_select('sex', 'Female'); ?>>Female</option>
                                <option value="Other" <?php echo set_select('sex', 'Other'); ?>>Other</option>
                            </select>
                        </div>
                        
                        <!-- Age -->
                        <div class="form-group">
                            <label for="age">Age *</label>
                            <input type="number" 
                                   class="form-control" 
                                   id="age" 
                                   name="age" 
                                   value="<?php echo set_value('age'); ?>" 
                                   min="13" 
                                   max="59" 
                                   required>
                            <small class="form-text text-muted">Age must be between 13 and 59</small>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <!-- Region -->
                        <div class="form-group">
                            <label for="region">Region *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="region" 
                                   name="region" 
                                   value="<?php echo set_value('region'); ?>" 
                                   required>
                        </div>
                        
                        <!-- Sport -->
                        <div class="form-group">
                            <label for="sport">Sport *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="sport" 
                                   name="sport" 
                                   value="<?php echo set_value('sport'); ?>" 
                                   required>
                        </div>
                        
                        <!-- Photo -->
                        <div class="form-group">
                            <label for="photo">Photo</label>
                            <div class="custom-file">
                                <input type="file" 
                                       class="custom-file-input" 
                                       id="photo" 
                                       name="photo" 
                                       accept="image/*">
                                <label class="custom-file-label" for="photo">Choose file</label>
                            </div>
                            <small class="form-text text-muted">Allowed types: JPG, PNG, GIF. Max size: 2MB</small>
                            
                            <!-- Photo Preview -->
                            <div class="mt-2" id="photoPreview" style="display: none;">
                                <img id="previewImage" src="" alt="Preview" style="max-width: 150px; max-height: 150px; border: 1px solid #ddd; padding: 5px;">
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Submit Button -->
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Register Athlete
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </button>
                </div>
                
            <?php echo form_close(); ?>
       </div>
  </div>
</div>
</div>
</section>
</div>


<!-- Preview Image Script -->
<script>
    // Preview uploaded image
    document.getElementById('photo').addEventListener('change', function(e) {
        var file = e.target.files[0];
        var preview = document.getElementById('previewImage');
        var previewDiv = document.getElementById('photoPreview');
        
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                previewDiv.style.display = 'block';
            }
            reader.readAsDataURL(file);
            
            // Update file label
            var fileName = file.name;
            var label = document.querySelector('.custom-file-label');
            label.textContent = fileName;
        } else {
            previewDiv.style.display = 'none';
            document.querySelector('.custom-file-label').textContent = 'Choose file';
        }
    });
</script>