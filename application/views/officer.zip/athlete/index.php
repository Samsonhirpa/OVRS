<div class="content-wrapper">
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fa fa-users mr-2"></i><?php echo $title; ?>
                </h1>
                <a href="<?php echo base_url('athlete/create'); ?>" class="btn btn-primary btn-sm">
                    <i class="fa fa-plus"></i> Add New Athlete
                </a>
            </div>

         
        <!-- Filters Card -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fa fa-filter mr-2"></i>Filter Athletes
                </h6>
            </div>
            <div class="card-body" id="filterSection">
                <div class="row align-items-end">
                    <!-- Sex Filter -->
                    <div class="col-md-3 mb-3">
                        <label for="sexFilter" class="font-weight-bold text-dark">Sex</label>
                        <select class="form-control filter-select" id="sexFilter">
                            <option value="">All Sex</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <!-- Age Range Filter -->
                    <div class="col-md-2 mb-3">
                        <label for="minAge" class="font-weight-bold text-dark">Min Age</label>
                        <input type="number" class="form-control filter-input" id="minAge" placeholder="Min" min="13" max="59">
                    </div>

                    <div class="col-md-2 mb-3">
                        <label for="maxAge" class="font-weight-bold text-dark">Max Age</label>
                        <input type="number" class="form-control filter-input" id="maxAge" placeholder="Max" min="13" max="59">
                    </div>

                    <!-- Sport Filter -->
                    <div class="col-md-3 mb-3">
                        <label for="sportFilter" class="font-weight-bold text-dark">Sport</label>
                        <select class="form-control filter-select" id="sportFilter">
                            <option value="">All Sports</option>
                            <?php
                            $sports = [];
                            if (!empty($athletes)) {
                                foreach ($athletes as $athlete) {
                                    if (!empty($athlete['sport']) && !in_array($athlete['sport'], $sports)) {
                                        $sports[] = $athlete['sport'];
                                    }
                                }
                                sort($sports);
                                foreach ($sports as $sport) {
                                    echo '<option value="' . htmlspecialchars($sport) . '">' . htmlspecialchars($sport) . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Region Filter -->
               <!--      <div class="col-md-2 mb-3">
                        <label for="regionFilter" class="font-weight-bold text-dark">Region</label>
                        <select class="form-control filter-select" id="regionFilter">
                            <option value="">All Regions</option>
                            <?php
                            $regions = [];
                            if (!empty($athletes)) {
                                foreach ($athletes as $athlete) {
                                    if (!empty($athlete['region']) && !in_array($athlete['region'], $regions)) {
                                        $regions[] = $athlete['region'];
                                    }
                                }
                                sort($regions);
                                foreach ($regions as $region) {
                                    echo '<option value="' . htmlspecialchars($region) . '">' . htmlspecialchars($region) . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
 -->
                    <!-- Apply & Reset Buttons -->
                    <div class="col-md-2 mb-3">
                        <div class="d-flex">
                            <button type="button" class="btn btn-primary btn-block mr-2" id="applyFilters">
                                <i class="fa fa-search fa-sm"></i> Apply
                            </button>
                          
                        </div>
                    </div>
                      <div class="col-md-2 mb-3">
                        <div class="d-flex">
                        
                            <button type="button" class="btn btn-secondary btn-block" id="resetFilters">
                                <i class="fa fa-redo fa-sm"></i> Reset
                                </button>
                            </div>
                        </div>
                    
                
          
                <!-- Active Filters Summary -->
                <div class="row mt-3">
                    <div class="col-12">
                        <div class="d-flex align-items-center">
                            <span class="font-weight-bold text-dark mr-3">Active Filters:</span>
                            <div class="filter-summary" id="filterSummary">
                                <span class="text-muted small">No active filters</span>
                            </div>
                        </div>
                    </div>
                </div>
           </div>
       </div>
   </div>
        


  

            <div class="card-body">
                <div class="table-responsive">
                    <table role="grid" aria-describedby="example1_info"class="table table-bordered table-hover" id="athletesTable" width="100%" cellspacing="0">
                        <thead class="thead-dark">
                            <tr>
                                <th>ID</th>
                                <th>Photo</th>
                                <th>Full Name</th>
                                <th>Sex</th>
                                <th>Age</th>
                                <th>Region</th>
                                <th>Sport</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($athletes)): ?>
                                <?php foreach ($athletes as $athlete): ?>
                                    <tr>
                                        <td><?php echo $athlete['id']; ?></td>
                                        <td class="text-center">
                                            <?php if (!empty($athlete['photo']) && file_exists(FCPATH . 'uploads/athletes/' . $athlete['photo'])): ?>
                                                <img src="<?php echo base_url('uploads/athletes/' . $athlete['photo']); ?>" 
                                                     alt="<?php echo htmlspecialchars($athlete['full_name']); ?>" 
                                                     class="rounded-circle img-thumbnail"
                                                     style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="rounded-circle d-inline-flex align-items-center justify-content-center bg-light"
                                                     style="width: 50px; height: 50px; border: 1px solid #dee2e6;">
                                                    <i class="fa fa-user text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($athlete['full_name']); ?></td>
                                        <td><?php echo $athlete['sex']; ?></td>
                                        <td><?php echo $athlete['age']; ?></td>
                                        <td><?php echo htmlspecialchars($athlete['region']); ?></td>
                                        <td><?php echo htmlspecialchars($athlete['sport']); ?></td>
                                        <td>
                                            <?php if (isset($athlete['created_at'])): ?>
                                                <?php echo date('d/m/Y', strtotime($athlete['created_at'])); ?>
                                            <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm" role="group">
                                                <a href="<?php echo site_url('athlete/edit/' . $athlete['id']); ?>" 
                                                   class="btn btn-warning"
                                                   title="Edit">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a href="<?php echo site_url('athlete/delete/' . $athlete['id']); ?>" 
                                                   class="btn btn-danger"
                                                   title="Delete"
                                                   onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars(addslashes($athlete['full_name'])); ?>?')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5">
                                        <div class="empty-state">
                                            <i class="fa fa-users fa-3x text-muted mb-3"></i>
                                            <h4 class="text-muted">No Athletes Found</h4>
                                            <a href="<?php echo site_url('athlete/create'); ?>" class="btn btn-primary">
                                                <i class="fa fa-plus mr-2"></i> Add First Athlete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    console.log("Initializing DataTable...");
    
    // Initialize DataTable
    var table = $('#athletesTable').DataTable({

        
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageLength": 10,
        "language": {
            "search": "Search:",
            "lengthMenu": "Show _MENU_ entries",
            "info": "Showing _START_ to _END_ of _TOTAL_ entries",
            "infoEmpty": "No entries available",
            "zeroRecords": "No matching records found"
        },
        "dom": "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
               "<'row'<'col-sm-12'tr>>" +
               "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>"
            , dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
    });
    
    console.log("DataTable initialized successfully");
     
  

  
    // Connect table search input to DataTable
    $('#tableSearch').on('keyup', function() {
        table.search(this.value).draw();
    });
    
    // Function to apply all filters
    function applyFilters() {
        console.log("Applying filters...");
        
        // Clear any existing custom filters
        $.fn.dataTable.ext.search = [];
        
        // Get filter values
        var sexFilter = $('#sexFilter').val();
        var minAge = $('#minAge').val();
        var maxAge = $('#maxAge').val();
        var sportFilter = $('#sportFilter').val();
        var regionFilter = $('#regionFilter').val();
        
        console.log("Filter values:", {
            sex: sexFilter,
            minAge: minAge,
            maxAge: maxAge,
            sport: sportFilter,
            region: regionFilter
        });
        
        // Add custom filtering function
        $.fn.dataTable.ext.search.push(
            function(settings, data, dataIndex) {
                var row = table.row(dataIndex).data();
                
                // Sex filter - column index 3
                if (sexFilter && data[3] !== sexFilter) {
                    return false;
                }
                
                // Age filter - column index 4
                var age = parseInt(data[4]);
                if (minAge && age < parseInt(minAge)) {
                    return false;
                }
                if (maxAge && age > parseInt(maxAge)) {
                    return false;
                }
                
                // Sport filter - column index 6
                if (sportFilter && data[6] !== sportFilter) {
                    return false;
                }
                
                // Region filter - column index 5
                if (regionFilter && data[5] !== regionFilter) {
                    return false;
                }
                
                return true;
            }
        );
        
        // Redraw the table
        table.draw();
        
        // Update UI
        updateRecordCount();
        updateFilterSummary();
        
        console.log("Filters applied successfully");
    }
    
    // Apply Filters button click
    $('#applyFilters').on('click', function(e) {
        e.preventDefault();
        console.log("Apply Filters button clicked");
        applyFilters();
    });
    
    // Reset Filters button click
    $('#resetFilters').on('click', function(e) {
        e.preventDefault();
        console.log("Reset Filters button clicked");
        
        // Reset all filter inputs
        $('.filter-select').val('');
        $('.filter-input').val('');
        $('#tableSearch').val('');
        
        // Clear DataTable filters and search
        $.fn.dataTable.ext.search = [];
        table.search('').draw();
        
        // Update UI
        updateRecordCount();
        $('#filterSummary').html('<span class="text-muted small">No active filters</span>');
        
        console.log("Filters reset");
    });
    
    // Apply filters when Enter is pressed in age fields
    $('#minAge, #maxAge').on('keyup', function(e) {
        if (e.keyCode === 13) { // Enter key
            applyFilters();
        }
    });
    
    // Auto-apply filters when dropdowns change (optional)
    $('.filter-select').on('change', function() {
        applyFilters();
    });
    
    // Update record count
    function updateRecordCount() {
        var count = table.rows({search: 'applied'}).count();
        $('#recordCount').text(count + ' records');
        console.log("Record count updated:", count);
    }
    
    // Update filter summary
    function updateFilterSummary() {
        var activeFilters = [];
        
        if ($('#sexFilter').val()) {
            activeFilters.push('<span class="badge badge-primary mr-2 mb-1">Sex: ' + $('#sexFilter').val() + '</span>');
        }
        
        var minAge = $('#minAge').val();
        var maxAge = $('#maxAge').val();
        if (minAge || maxAge) {
            var ageText = 'Age: ';
            if (minAge) ageText += minAge + '+';
            if (minAge && maxAge) ageText += ' to ';
            if (maxAge) ageText += maxAge;
            activeFilters.push('<span class="badge badge-info mr-2 mb-1">' + ageText + '</span>');
        }
        
        if ($('#sportFilter').val()) {
            activeFilters.push('<span class="badge badge-success mr-2 mb-1">Sport: ' + $('#sportFilter').val() + '</span>');
        }
        
        if ($('#regionFilter').val()) {
            activeFilters.push('<span class="badge badge-warning mr-2 mb-1">Region: ' + $('#regionFilter').val() + '</span>');
        }
        
        if ($('#tableSearch').val()) {
            activeFilters.push('<span class="badge badge-secondary mr-2 mb-1">Search: ' + $('#tableSearch').val() + '</span>');
        }
        
        var summary = $('#filterSummary');
        if (activeFilters.length > 0) {
            summary.html(activeFilters.join(''));
        } else {
            summary.html('<span class="text-muted small">No active filters</span>');
        }
    }
    
    // Update record count when table is drawn
    table.on('draw', function() {
        updateRecordCount();
        updateFilterSummary();
    });
    
    // Initial UI update
    updateRecordCount();
    
    console.log("All event handlers registered");
});
</script>

<style>
    .content-wrapper {
        background-color: #f8f9fc;
    }
    
    .card {
        border: none;
        border-radius: 8px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        margin-bottom: 20px;
    }
    
    .card-header {
        background-color: white;
        border-bottom: 1px solid #e3e6f0;
        padding: 1rem 1.35rem;
    }
    
    #athletesTable {
        border-collapse: separate;
        border-spacing: 0;
    }
    
    #athletesTable thead th {
        background-color: #4e73df;
        color: white;
        border: none;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 12px;
        letter-spacing: 0.5px;
        padding: 12px 10px;
    }
    
    #athletesTable tbody td {
        padding: 12px 10px;
        vertical-align: middle;
        border-top: 1px solid #e3e6f0;
    }
    
    #athletesTable tbody tr:hover {
        background-color: #f8f9fa;
    }
    
    .badge-pink {
        background-color: #e83e8c;
        color: white;
    }
    
    .filter-summary {
        min-height: 30px;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
    }
    
    .filter-summary .badge {
        font-size: 0.8rem;
        padding: 0.35em 0.65em;
    }
    
    .btn-group .btn {
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        margin-right: 3px;
    }
    
    .form-control:focus {
        border-color: #4e73df;
        box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
    }
    
    .dataTables_wrapper .dataTables_filter input {
        border: 1px solid #d1d3e2;
        border-radius: 4px;
        padding: 6px 12px;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .card-header {
            flex-direction: column;
            align-items: flex-start !important;
        }
        
        .card-header > div {
            margin-top: 10px;
            width: 100%;
        }
        
        #tableSearch {
            width: 100% !important;
            margin-top: 10px;
        }
        
        .filter-summary .badge {
            margin-bottom: 5px;
        }
    }
</style>

<!-- REQUIRED CDN LINKS -->
<!-- Add these to your layout/header.php -->
<!--
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
-->