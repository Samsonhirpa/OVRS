<div class="content-wrapper">
    <div class="page-content">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fa fa-users mr-2"></i><?php echo $title; ?>
                </h1>
               
                <a href="<?php echo base_url('officer/create'); ?>" class="btn btn-primary btn-sm">
                    <i class="fa fa-plus"></i> Register New Officer
                </a>
            </div>

         

            <!-- Filters Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fa fa-filter mr-2"></i>Filter Officers
                    </h6>
                </div>
                <div class="card-body" id="filterSection">
                    <div class="row align-items-end">
                        <!-- Search by Name -->
                        <div class="col-md-4 mb-4">
                            <label for="nameSearch" class="font-weight-bold text-dark">Search by Name</label>
                            <div class="input-group">
                                <input type="text" class="form-control filter-input" id="nameSearch" 
                                       placeholder="Enter officer name...">
                             <button class="btn btn-outline-primary" type="button" id="searchBtn">
                                        <i class="fa fa-search"></i>
                                    </button>
                                    
                                
                            </div>
                        </div>

                        <!-- Sex Filter -->
                        <div class="col-md-3 mb-3">
                            <label for="sexFilter" class="font-weight-bold text-dark">Sex</label>
                            <select class="form-control filter-select" id="sexFilter">
                                <option value="">All Sex</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <!-- Region Filter -->
                        <div class="col-md-3 mb-3">
                            <label for="regionFilter" class="font-weight-bold text-dark">Region</label>
                            <select class="form-control filter-select" id="regionFilter">
                                <option value="">All Regions</option>
                                <?php
                                $regions = $this->Officer_model->get_regions();
                                foreach ($regions as $region) {
                                    echo '<option value="' . $region . '">' . $region . '</option>';
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Apply & Reset Buttons -->
                        <div class="col-md-2 mb-3">
                            <div class="d-flex">
                                <button type="button" class="btn btn-primary btn-block mr-2" id="applyFilters">
                                    <i class="fa fa-search fa-sm"></i> Apply
                                </button>
                                <button type="button" class="btn btn-secondary btn-block" id="resetFilters">
                                    <i class="fa fa-redo fa-sm"></i> Reset
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Active Filters Summary -->
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="d-flex align-items-center">
                                <span class="font-weight-bold text-dark mr-3">Active Filters:</span>
                                <div class="filter-summary" id="filterSummary">
                                    <span class="text-muted small">No active filters</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Officers List Card -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fa fa-list mr-2"></i>Registered Officers List
                        <span class="badge badge-primary ml-2" id="recordCount">
                            <?php echo count($officers); ?> officers
                        </span>
                    </h6>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="officersTable" width="100%" cellspacing="0">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Photo</th>
                                    <th>Full Name</th>
                                    <th>Sex</th>
                                    <th>Region</th>
                                    <th>Position</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($officers)): ?>
                                    <?php foreach ($officers as $officer): ?>
                                        <tr>
                                            <td><?php echo $officer['id']; ?></td>
                                            <td class="text-center">
                                                <?php if (!empty($officer['photo']) && file_exists(FCPATH . 'uploads/officers/' . $officer['photo'])): ?>
                                                    <img src="<?php echo base_url('uploads/officers/' . $officer['photo']); ?>" 
                                                         alt="<?php echo htmlspecialchars($officer['full_name']); ?>" 
                                                         class="rounded-circle img-thumbnail"
                                                         style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center bg-light"
                                                         style="width: 50px; height: 50px; border: 1px solid #dee2e6;">
                                                        <i class="fa fa-user-tie text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($officer['full_name']); ?></td>
                                            <td><?php echo $officer['sex']; ?></td>
                                            <td><?php echo htmlspecialchars($officer['region']); ?></td>
                                            <td><?php echo htmlspecialchars($officer['position']); ?></td>
                                            <td>
                                                <?php if (isset($officer['created_at'])): ?>
                                                    <?php echo date('d/m/Y', strtotime($officer['created_at'])); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm" role="group">
                                                    <a href="<?php echo site_url('officer/edit/' . $officer['id']); ?>" 
                                                       class="btn btn-warning"
                                                       title="Edit">
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                    <a href="<?php echo site_url('officer/delete/' . $officer['id']); ?>" 
                                                       class="btn btn-danger"
                                                       title="Delete"
                                                       onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars(addslashes($officer['full_name'])); ?>?')">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-5">
                                            <div class="empty-state">
                                                <i class="fa fa-user-tie fa-3x text-muted mb-3"></i>
                                                <h4 class="text-muted">No Officers Found</h4>
                                                <a href="<?php echo site_url('officer/create'); ?>" class="btn btn-primary">
                                                    <i class="fa fa-plus mr-2"></i> Register First Officer
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- DataTables Script -->
<script>
$(document).ready(function() {
    // Initialize DataTable
    var table = $('#officersTable').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "pageLength": 10,
        "language": {
            "search": "Search:",
            "lengthMenu": "Show _MENU_ entries",
            "info": "Showing _START_ to _END_ of _TOTAL_ entries",
            "infoEmpty": "No entries available",
            "zeroRecords": "No matching records found"
        },
        "dom": "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
               "<'row'<'col-sm-12'tr>>" +
               "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>"
    });
    
    // Function to apply all filters
    function applyFilters() {
        // Clear any existing custom filters
        $.fn.dataTable.ext.search = [];
        
        // Get filter values
        var nameSearch = $('#nameSearch').val();
        var sexFilter = $('#sexFilter').val();
        var regionFilter = $('#regionFilter').val();
        
        // Add custom filtering function
        $.fn.dataTable.ext.search.push(
            function(settings, data, dataIndex) {
                // Name search
                if (nameSearch) {
                    var name = data[2].toLowerCase();
                    if (name.indexOf(nameSearch.toLowerCase()) === -1) {
                        return false;
                    }
                }
                
                // Sex filter - column index 3
                if (sexFilter && data[3] !== sexFilter) {
                    return false;
                }
                
                // Region filter - column index 4
                if (regionFilter && data[4] !== regionFilter) {
                    return false;
                }
                
                return true;
            }
        );
        
        // Redraw the table
        table.draw();
        
        // Update UI
        updateRecordCount();
        updateFilterSummary();
    }
    
    // Apply Filters button click
    $('#applyFilters').on('click', function() {
        applyFilters();
    });
    
    // Search button click
    $('#searchBtn').on('click', function() {
        applyFilters();
    });
    
    // Enter key in search field
    $('#nameSearch').on('keyup', function(e) {
        if (e.keyCode === 13) {
            applyFilters();
        }
    });
    
    // Reset Filters button click
    $('#resetFilters').on('click', function() {
        // Reset all filter inputs
        $('.filter-select').val('');
        $('.filter-input').val('');
        
        // Clear DataTable filters
        $.fn.dataTable.ext.search = [];
        table.search('').draw();
        
        // Update UI
        updateRecordCount();
        $('#filterSummary').html('<span class="text-muted small">No active filters</span>');
    });
    
    // Auto-apply filters when dropdowns change
    $('.filter-select').on('change', function() {
        applyFilters();
    });
    
    // Update record count
    function updateRecordCount() {
        var count = table.rows({search: 'applied'}).count();
        $('#recordCount').text(count + ' officers');
    }
    
    // Update filter summary
    function updateFilterSummary() {
        var activeFilters = [];
        
        if ($('#nameSearch').val()) {
            activeFilters.push('<span class="badge badge-primary mr-2 mb-1">Name: ' + $('#nameSearch').val() + '</span>');
        }
        
        if ($('#sexFilter').val()) {
            activeFilters.push('<span class="badge badge-info mr-2 mb-1">Sex: ' + $('#sexFilter').val() + '</span>');
        }
        
        if ($('#regionFilter').val()) {
            activeFilters.push('<span class="badge badge-success mr-2 mb-1">Region: ' + $('#regionFilter').val() + '</span>');
        }
        
        var summary = $('#filterSummary');
        if (activeFilters.length > 0) {
            summary.html(activeFilters.join(''));
        } else {
            summary.html('<span class="text-muted small">No active filters</span>');
        }
    }
    
    // Update record count when table is drawn
    table.on('draw', function() {
        updateRecordCount();
        updateFilterSummary();
    });
    
    // Initial UI update
    updateRecordCount();
});
</script>

<style>
    .content-wrapper {
        background-color: #f8f9fc;
    }
    
    .card {
        border: none;
        border-radius: 8px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        margin-bottom: 20px;
    }
    
    .card-header {
        background-color: white;
        border-bottom: 1px solid #e3e6f0;
        padding: 1rem 1.35rem;
    }
    
    #officersTable {
        border-collapse: separate;
        border-spacing: 0;
    }
    
    #officersTable thead th {
        background-color: #4e73df;
        color: white;
        border: none;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 12px;
        letter-spacing: 0.5px;
        padding: 12px 10px;
    }
    
    #officersTable tbody td {
        padding: 12px 10px;
        vertical-align: middle;
        border-top: 1px solid #e3e6f0;
    }
    
    #officersTable tbody tr:hover {
        background-color: #f8f9fa;
    }
    
    .filter-summary {
        min-height: 30px;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
    }
    
    .filter-summary .badge {
        font-size: 0.8rem;
        padding: 0.35em 0.65em;
    }
    
    .btn-group .btn {
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        margin-right: 3px;
    }
    
    .form-control:focus {
        border-color: #4e73df;
        box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
    }
    
    .empty-state {
        padding: 40px 0;
        text-align: center;
    }
    
    .empty-state i {
        font-size: 64px;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    @media (max-width: 768px) {
        .card-header {
            flex-direction: column;
            align-items: flex-start !important;
        }
        
        .card-header > div {
            margin-top: 10px;
            width: 100%;
        }
        
        .filter-summary .badge {
            margin-bottom: 5px;
        }
    }
</style>