<!-- application/views/officer/create.php -->
<div class="content-wrapper">
    <section class="content" style="min-height: 526px;">
        <div class="col-xs-12">
            <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
                <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>
            </div>
        </div>

        <!-- Back Button -->
      

         <div class="mb-3">
        <a href="<?php echo site_url('officer'); ?>" class="btn btn-secondary">
            <i class="fa fa-arrow-left"></i> Back to List
        </a>
        
    </div>

        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">

                <!-- Form -->
                <div class="card shadow mb-4">
                    
                    <div class="card-body">
                        <?php echo form_open_multipart('officer/store'); ?>
                        
                            <!-- Validation Errors -->
                            <?php if (validation_errors()): ?>
                                <div class="alert alert-danger">
                                    <?php echo validation_errors(); ?>
                                </div>
                            <?php endif; ?>

                           <div class="box-header with-border">
                               <div class="callout callout-info">
                                    <h4 class="box-title">Officer Information</h4>
                               </div>
                           

                           <div class="row">
                                <div class="col-md-6">
                                    <!-- Full Name -->
                                    <div class="form-group">
                                        <label for="full_name">FULL NAME *</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="full_name" 
                                               name="full_name" 
                                               value="<?php echo set_value('full_name'); ?>" 
                                               placeholder="ENTER FULL NAME"
                                               required>
                                    </div>
                                    
                                    <!-- Sex -->
                                    <div class="form-group">
                                        <label for="sex">SEX *</label>
                                        <select class="form-control" id="sex" name="sex" required>
                                            <option value="">SELECT SEX</option>
                                            <option value="Male" <?php echo set_select('sex', 'Male'); ?>>Male</option>
                                            <option value="Female" <?php echo set_select('sex', 'Female'); ?>>Female</option>
                                            <option value="Other" <?php echo set_select('sex', 'Other'); ?>>Other</option>
                                        </select>
                                    </div>
                                    
                                    <!-- Region -->
                                    <div class="form-group">
                                        <label for="region">REGION *</label>
                                        <select class="form-control" id="region" name="region" required>
                                            <option value="">SELECT REGION</option>
                                            <?php
                                            $regions = $this->Officer_model->get_regions();
                                            foreach ($regions as $region) {
                                                $selected = set_select('region', $region);
                                                echo '<option value="' . $region . '" ' . $selected . '>' . $region . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <!-- Position -->
                                    <div class="form-group">
                                        <label for="position">የኮራ ድርሻ (POSITION) *</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="position" 
                                               name="position" 
                                               value="<?php echo set_value('position'); ?>" 
                                               placeholder="የኮራ ድርሻ አቶምሪኩ"
                                               required>
                                    </div>
                                    
                                    <!-- Officer Photo -->
                                    <div class="form-group">
                                        <label for="photo">OFFICER PHOTO</label>
                                        <div class="custom-file">
                                            <input type="file" 
                                                   class="custom-file-input" 
                                                   id="photo" 
                                                   name="photo" 
                                                   accept="image/*">
                                            <label class="custom-file-label" for="photo">Browse... No file selected.</label>
                                        </div>
                                        <small class="form-text text-muted">Upload officer's photo (JPEG, PNG, GIF - Max 2MB)</small>
                                        
                                        <!-- Photo Preview -->
                                        <div class="mt-2" id="photoPreview" style="display: none;">
                                            <label class="font-weight-bold">Photo Preview:</label><br>
                                            <img id="previewImage" src="" alt="Preview" 
                                                 style="max-width: 150px; max-height: 150px; border: 1px solid #ddd; padding: 5px;">
                                        </div>
                                    </div>
                                    
                                    <!-- Registration Date (Auto-generated) -->
                                    <div class="form-group">
                                        <label>Registration Date</label>
                                        <input type="text" 
                                               class="form-control" 
                                               value="<?php echo date('d/m/Y'); ?>" 
                                               readonly>
                                        <small class="form-text text-muted">Auto-generated registration date</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Submit Button -->
                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fa fa-save"></i> REGISTER OFFICER
                                </button>
                                <button type="reset" class="btn btn-danger btn-lg">
                                    <i class="fa fa-redo"></i> CLEAR FORM
                                </button>
                            </div>
                            
                            <!-- Footer -->
                            <div class="mt-5 pt-3 border-top text-center text-muted">
                                <small>© 2026 Oromia Games</small>
                            </div>
                            
                        <?php echo form_close(); ?>
                   </div>
              </div>
              </div>
          </div>
      </div>
  </section>
</div>

<!-- Preview Image Script -->
<script>
    // Preview uploaded image
    document.getElementById('photo').addEventListener('change', function(e) {
        var file = e.target.files[0];
        var preview = document.getElementById('previewImage');
        var previewDiv = document.getElementById('photoPreview');
        var label = document.querySelector('.custom-file-label');
        
        if (file) {
            // Validate file size (2MB max)
            if (file.size > 2 * 1024 * 1024) {
                alert('File size must be less than 2MB');
                this.value = '';
                label.textContent = 'Browse... No file selected.';
                previewDiv.style.display = 'none';
                return;
            }
            
            // Validate file type
            var validTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!validTypes.includes(file.type)) {
                alert('Only JPG, PNG, and GIF files are allowed');
                this.value = '';
                label.textContent = 'Browse... No file selected.';
                previewDiv.style.display = 'none';
                return;
            }
            
            var reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                previewDiv.style.display = 'block';
            }
            reader.readAsDataURL(file);
            
            // Update file label
            label.textContent = file.name;
        } else {
            previewDiv.style.display = 'none';
            label.textContent = 'Browse... No file selected.';
        }
    });

    // Form validation
    document.querySelector('form').addEventListener('submit', function(e) {
        var fullName = document.getElementById('full_name').value.trim();
        var sex = document.getElementById('sex').value;
        var region = document.getElementById('region').value;
        var position = document.getElementById('position').value.trim();
        
        // Check required fields
        var isValid = true;
        var errorMessages = [];
        
        if (!fullName) {
            errorMessages.push('Full Name is required');
            document.getElementById('full_name').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('full_name').classList.remove('is-invalid');
        }
        
        if (!sex) {
            errorMessages.push('Sex is required');
            document.getElementById('sex').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('sex').classList.remove('is-invalid');
        }
        
        if (!region) {
            errorMessages.push('Region is required');
            document.getElementById('region').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('region').classList.remove('is-invalid');
        }
        
        if (!position) {
            errorMessages.push('Position is required');
            document.getElementById('position').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('position').classList.remove('is-invalid');
        }
        
        if (!isValid) {
            e.preventDefault();
            var errorMessage = 'Please fix the following errors:\n\n' + errorMessages.join('\n');
            alert(errorMessage);
            return false;
        }
        
        return true;
    });

    // Reset form validation styles
    document.querySelector('button[type="reset"]').addEventListener('click', function() {
        var formControls = document.querySelectorAll('.form-control');
        formControls.forEach(function(control) {
            control.classList.remove('is-invalid');
        });
        
        // Reset file input
        var fileInput = document.getElementById('photo');
        var label = document.querySelector('.custom-file-label');
        fileInput.value = '';
        label.textContent = 'Browse... No file selected.';
        document.getElementById('photoPreview').style.display = 'none';
    });

    // Custom file input styling
    document.querySelector('.custom-file-input').addEventListener('change', function() {
        var fileName = this.value.split('\\').pop();
        var label = this.nextElementSibling;
        
        if (fileName) {
            label.classList.add("selected");
            label.innerHTML = fileName;
        } else {
            label.classList.remove("selected");
            label.innerHTML = 'Browse... No file selected.';
        }
    });
</script>

<style>
    .content-wrapper {
        background-color: #f4f6f9;
    }
    
    .box {
        border-top: 3px solid #3c8dbc;
        background: #fff;
        margin-bottom: 20px;
        border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    }
    
    .box-primary {
        border-top-color: #3c8dbc;
    }
    
    .box-header {
        color: #444;
        display: block;
        padding: 10px;
        position: relative;
        border-bottom: 1px solid #f4f4f4;
    }
    
    .box-header .box-title {
        display: inline-block;
        font-size: 18px;
        margin: 0;
        line-height: 1;
        font-weight: 500;
    }
    
    .callout {
        border-radius: 3px;
        margin: 0 0 20px 0;
        padding: 15px 30px 15px 15px;
        border-left: 5px solid #eee;
    }
    
    .callout-info {
        background-color: #f0f9ff;
        border-color: #3c8dbc;
        color: #31708f;
    }
    
    .form-control {
        border-radius: 3px;
        box-shadow: none;
        border-color: #d2d6de;
        padding: 10px 12px;
        height: auto;
    }
    
    .form-control:focus {
        border-color: #3c8dbc;
        box-shadow: 0 0 0 0.2rem rgba(60, 141, 188, 0.25);
    }
    
    .form-control.is-invalid {
        border-color: #dc3545;
    }
    
    .form-control.is-invalid:focus {
        border-color: #dc3545;
        box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
    }
    
    .btn {
        border-radius: 3px;
        font-weight: 500;
        padding: 10px 20px;
        font-size: 16px;
    }
    
    .btn-lg {
        padding: 12px 30px;
        font-size: 18px;
    }
    
    .btn-primary {
        background-color: #3c8dbc;
        border-color: #367fa9;
    }
    
    .btn-primary:hover {
        background-color: #367fa9;
        border-color: #307095;
    }
    
    .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
    }
    
    .btn-secondary:hover {
        background-color: #5a6268;
        border-color: #545b62;
    }
    
    .custom-file-label {
        border-radius: 3px;
        border-color: #d2d6de;
        padding: 10px 12px;
        height: auto;
        line-height: 1.5;
    }
    
    .custom-file-input:focus ~ .custom-file-label {
        border-color: #3c8dbc;
        box-shadow: 0 0 0 0.2rem rgba(60, 141, 188, 0.25);
    }
    
    .custom-file-label::after {
        content: "Browse";
        height: auto;
        line-height: 1.5;
        padding: 10px 12px;
        background-color: #e9ecef;
        border-left: 1px solid #d2d6de;
    }
    
    .img-thumbnail {
        border: 3px solid #ddd;
        border-radius: 5px;
    }
    
    .alert {
        border-radius: 3px;
        border: 1px solid transparent;
        margin-bottom: 20px;
    }
    
    .alert-danger {
        background-color: #f8d7da;
        border-color: #f5c6cb;
        color: #721c24;
    }
    
    .border-top {
        border-top: 1px solid #dee2e6 !important;
    }
    
    .text-muted {
        color: #6c757d !important;
    }
    
    .font-weight-bold {
        font-weight: 600 !important;
    }
    
    label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 5px;
    }
    
    /* Make the form look like the image */
    .form-control::placeholder {
        color: #6c757d;
        opacity: 0.7;
    }
    
    /* Style the select dropdown */
    select.form-control {
        appearance: none;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 0.75rem center;
        background-size: 8px 10px;
        padding-right: 2rem;
    }
</style>