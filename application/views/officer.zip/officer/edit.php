<!-- application/views/officer/edit.php -->
<div class="content-wrapper">
    <section class="content">
        <div class="col-xs-12">
            <div class="col-lg-12 col-sm-12 col-xs-12 no-padding">
                <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>
            </div>
        </div>

  

    <!-- Back Button -->
    <div class="mb-3">
       <a href="<?php echo site_url('officer'); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
        
    </div>
    
 <div class="box-header with-border">
                   

        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">

                <!-- Form -->
                <div class="card shadow mb-4">
                    
                    <div class="card-body">
                        <?php echo form_open_multipart('officer/update/' . $officer->id); ?>
                        
                         

                           <div class="box-header with-border">
                               <div class="callout callout-info">
                                    <h4 class="box-title">Edit Officer Information</h4>
                               </div>
                           </div>

                           <div class="row">
                               <!-- Current Photo Preview -->
                               <div class="col-md-12 mb-4 text-center">
                                    <div class="form-group">
                                        <label class="font-weight-bold">Current Photo</label>
                                        <div>
                                            <?php if (!empty($officer->photo) && file_exists(FCPATH . 'uploads/officers/' . $officer->photo)): ?>
                                                <img src="<?php echo base_url('uploads/officers/' . $officer->photo); ?>" 
                                                     alt="<?php echo htmlspecialchars($officer->full_name); ?>" 
                                                     class="img-thumbnail"
                                                     style="width: 150px; height: 150px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="d-inline-flex align-items-center justify-content-center bg-light rounded-circle"
                                                     style="width: 150px; height: 150px; border: 2px solid #dee2e6;">
                                                    <i class="fa fa-user-tie fa-3x text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <small class="text-muted">Officer ID: <?php echo $officer->id; ?></small>
                                    </div>
                               </div>
                           </div>
 <div class="box-header with-border">
                           <div class="row">
                                <div class="col-md-6">
                                    <!-- Full Name -->
                                    <div class="form-group">
                                        <label for="full_name">FULL NAME *</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="full_name" 
                                               name="full_name" 
                                               value="<?php echo set_value('full_name', $officer->full_name); ?>" 
                                               placeholder="ENTER FULL NAME"
                                               required>
                                    </div>
                                    
                                    <!-- Sex -->
                                    <div class="form-group">
                                        <label for="sex">SEX *</label>
                                        <select class="form-control" id="sex" name="sex" required>
                                            <option value="">SELECT SEX</option>
                                            <option value="Male" <?php echo set_select('sex', 'Male', $officer->sex == 'Male'); ?>>Male</option>
                                            <option value="Female" <?php echo set_select('sex', 'Female', $officer->sex == 'Female'); ?>>Female</option>
                                            <option value="Other" <?php echo set_select('sex', 'Other', $officer->sex == 'Other'); ?>>Other</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <!-- Region -->
                                    <div class="form-group">
                                        <label for="region">REGION *</label>
                                        <select class="form-control" id="region" name="region" required>
                                            <option value="">SELECT REGION</option>
                                            <?php
                                            $regions = $this->Officer_model->get_regions();
                                            foreach ($regions as $region) {
                                                $selected = set_select('region', $region, $officer->region == $region);
                                                echo '<option value="' . $region . '" ' . $selected . '>' . $region . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    
                                    <!-- Position -->
                                    <div class="form-group">
                                        <label for="position">የኮራ ድርሻ (POSITION) *</label>
                                        <input type="text" 
                                               class="form-control" 
                                               id="position" 
                                               name="position" 
                                               value="<?php echo set_value('position', $officer->position); ?>" 
                                               placeholder="የኮራ ድርሻ አቶምሪኩ"
                                               required>
                                    </div>
                                </div>
                           </div>

                           <div class="row">
                                <div class="col-md-12">
                                    <!-- Existing Photo Hidden Field -->
                                    <input type="hidden" name="existing_photo" value="<?php echo $officer->photo; ?>">
                                    
                                    <!-- Photo Upload -->
                                    <div class="form-group">
                                        <label for="photo">Upload New Photo (Optional)</label>
                                        <div class="custom-file">
                                            <input type="file" 
                                                   class="custom-file-input" 
                                                   id="photo" 
                                                   name="photo" 
                                                   accept="image/*">
                                            <label class="custom-file-label" for="photo">
                                                Browse... No file selected.
                                            </label>
                                        </div>
                                        <small class="form-text text-muted">Upload new officer photo (JPEG, PNG, GIF - Max 2MB)</small>
                                        
                                        <!-- New Photo Preview -->
                                        <div class="mt-2" id="newPhotoPreview" style="display: none;">
                                            <label class="font-weight-bold">New Photo Preview:</label><br>
                                            <img id="previewImage" src="" alt="Preview" 
                                                 style="max-width: 150px; max-height: 150px; border: 1px solid #ddd; padding: 5px;">
                                        </div>
                                    </div>
                                </div>
                           </div>

                           <div class="row">
                                <div class="col-md-6">
                                    <!-- Created Date (Readonly) -->
                                    <div class="form-group">
                                        <label>Registration Date</label>
                                        <input type="text" 
                                               class="form-control" 
                                               value="<?php echo date('d/m/Y H:i:s', strtotime($officer->created_at)); ?>" 
                                               readonly>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <!-- Updated Date (Readonly) -->
                                    <div class="form-group">
                                        <label>Last Updated</label>
                                        <input type="text" 
                                               class="form-control" 
                                               value="<?php echo !empty($officer->updated_at) && $officer->updated_at != $officer->created_at ? date('d/m/Y H:i:s', strtotime($officer->updated_at)) : 'Not updated yet'; ?>" 
                                               readonly>
                                    </div>
                                </div>
                           </div>
                            
                            <!-- Submit Buttons -->
                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-save"></i> UPDATE OFFICER
                                </button>
                                <button type="reset" class="btn btn-secondary btn-lg">
                                    <i class="fas fa-redo"></i> RESET CHANGES
                                </button>
                                <a href="<?php echo site_url('officer/delete/' . $officer->id); ?>" 
                                   class="btn btn-danger btn-lg"
                                   onclick="return confirm('Are you sure you want to delete <?php echo htmlspecialchars(addslashes($officer->full_name)); ?>? This action cannot be undone.')">
                                    <i class="fas fa-trash"></i> DELETE OFFICER
                                </a>
                            </div>
                            
                            <!-- Footer -->
                            <div class="mt-5 pt-3 border-top text-center text-muted">
                                <small>© 2026 Oromia Games</small>
                            </div>
                            
                        <?php echo form_close(); ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
</section>
</div>

<!-- Preview Image Script -->
<script>
    // Preview uploaded image
    document.getElementById('photo').addEventListener('change', function(e) {
        var file = e.target.files[0];
        var preview = document.getElementById('previewImage');
        var previewDiv = document.getElementById('newPhotoPreview');
        var label = document.querySelector('.custom-file-label');
        
        if (file) {
            // Validate file size (2MB max)
            if (file.size > 2 * 1024 * 1024) {
                alert('File size must be less than 2MB');
                this.value = '';
                label.textContent = 'Browse... No file selected.';
                previewDiv.style.display = 'none';
                return;
            }
            
            // Validate file type
            var validTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!validTypes.includes(file.type)) {
                alert('Only JPG, PNG, and GIF files are allowed');
                this.value = '';
                label.textContent = 'Browse... No file selected.';
                previewDiv.style.display = 'none';
                return;
            }
            
            var reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                previewDiv.style.display = 'block';
            }
            reader.readAsDataURL(file);
            
            // Update file label
            label.textContent = file.name;
        } else {
            previewDiv.style.display = 'none';
            label.textContent = 'Browse... No file selected.';
        }
    });

    // Form validation
    document.querySelector('form').addEventListener('submit', function(e) {
        var fullName = document.getElementById('full_name').value.trim();
        var sex = document.getElementById('sex').value;
        var region = document.getElementById('region').value;
        var position = document.getElementById('position').value.trim();
        
        // Check required fields
        var isValid = true;
        var errorMessages = [];
        
        if (!fullName) {
            errorMessages.push('Full Name is required');
            document.getElementById('full_name').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('full_name').classList.remove('is-invalid');
        }
        
        if (!sex) {
            errorMessages.push('Sex is required');
            document.getElementById('sex').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('sex').classList.remove('is-invalid');
        }
        
        if (!region) {
            errorMessages.push('Region is required');
            document.getElementById('region').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('region').classList.remove('is-invalid');
        }
        
        if (!position) {
            errorMessages.push('Position is required');
            document.getElementById('position').classList.add('is-invalid');
            isValid = false;
        } else {
            document.getElementById('position').classList.remove('is-invalid');
        }
        
        if (!isValid) {
            e.preventDefault();
            var errorMessage = 'Please fix the following errors:\n\n' + errorMessages.join('\n');
            alert(errorMessage);
            return false;
        }
        
        return true;
    });

    // Reset form validation styles
    document.querySelector('button[type="reset"]').addEventListener('click', function() {
        var formControls = document.querySelectorAll('.form-control');
        formControls.forEach(function(control) {
            control.classList.remove('is-invalid');
        });
        
        // Reset file input
        var fileInput = document.getElementById('photo');
        var label = document.querySelector('.custom-file-label');
        fileInput.value = '';
        label.textContent = 'Browse... No file selected.';
        document.getElementById('newPhotoPreview').style.display = 'none';
    });

    // Custom file input styling
    document.querySelector('.custom-file-input').addEventListener('change', function() {
        var fileName = this.value.split('\\').pop();
        var label = this.nextElementSibling;
        
        if (fileName) {
            label.classList.add("selected");
            label.innerHTML = fileName;
        } else {
            label.classList.remove("selected");
            label.innerHTML = 'Browse... No file selected.';
        }
    });
</script>

<style>
    .content-wrapper {
        background-color: #f4f6f9;
    }
    
    .box {
        border-top: 3px solid #3c8dbc;
        background: #fff;
        margin-bottom: 20px;
        border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
    }
    
    .box-primary {
        border-top-color: #3c8dbc;
    }
    
    .box-header {
        color: #444;
        display: block;
        padding: 10px;
        position: relative;
        border-bottom: 1px solid #f4f4f4;
    }
    
    .box-header .box-title {
        display: inline-block;
        font-size: 18px;
        margin: 0;
        line-height: 1;
        font-weight: 500;
    }
    
    .callout {
        border-radius: 3px;
        margin: 0 0 20px 0;
        padding: 15px 30px 15px 15px;
        border-left: 5px solid #eee;
    }
    
    .callout-info {
        background-color: #f0f9ff;
        border-color: #3c8dbc;
        color: #31708f;
    }
    
    .form-control {
        border-radius: 3px;
        box-shadow: none;
        border-color: #d2d6de;
        padding: 10px 12px;
        height: auto;
    }
    
    .form-control:focus {
        border-color: #3c8dbc;
        box-shadow: 0 0 0 0.2rem rgba(60, 141, 188, 0.25);
    }
    
    .form-control.is-invalid {
        border-color: #dc3545;
    }
    
    .form-control.is-invalid:focus {
        border-color: #dc3545;
        box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
    }
    
    .btn {
        border-radius: 3px;
        font-weight: 500;
        padding: 10px 20px;
        font-size: 16px;
    }
    
    .btn-lg {
        padding: 12px 30px;
        font-size: 18px;
    }
    
    .btn-primary {
        background-color: #3c8dbc;
        border-color: #367fa9;
    }
    
    .btn-primary:hover {
        background-color: #367fa9;
        border-color: #307095;
    }
    
    .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
    }
    
    .btn-secondary:hover {
        background-color: #5a6268;
        border-color: #545b62;
    }
    
    .btn-danger {
        background-color: #dc3545;
        border-color: #dc3545;
    }
    
    .btn-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
    }
    
    .custom-file-label {
        border-radius: 3px;
        border-color: #d2d6de;
        padding: 10px 12px;
        height: auto;
        line-height: 1.5;
    }
    
    .custom-file-input:focus ~ .custom-file-label {
        border-color: #3c8dbc;
        box-shadow: 0 0 0 0.2rem rgba(60, 141, 188, 0.25);
    }
    
    .custom-file-label::after {
        content: "Browse";
        height: auto;
        line-height: 1.5;
        padding: 10px 12px;
        background-color: #e9ecef;
        border-left: 1px solid #d2d6de;
    }
    
    .img-thumbnail {
        border: 3px solid #ddd;
        border-radius: 5px;
    }
    
    .alert {
        border-radius: 3px;
        border: 1px solid transparent;
        margin-bottom: 20px;
    }
    
    .alert-success {
        background-color: #d4edda;
        border-color: #c3e6cb;
        color: #155724;
    }
    
    .alert-danger {
        background-color: #f8d7da;
        border-color: #f5c6cb;
        color: #721c24;
    }
    
    .border-top {
        border-top: 1px solid #dee2e6 !important;
    }
    
    .text-muted {
        color: #6c757d !important;
    }
    
    .font-weight-bold {
        font-weight: 600 !important;
    }
    
    label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 5px;
    }
    
    /* Make the form look like the image */
    .form-control::placeholder {
        color: #6c757d;
        opacity: 0.7;
    }
    
    /* Style the select dropdown */
    select.form-control {
        appearance: none;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 0.75rem center;
        background-size: 8px 10px;
        padding-right: 2rem;
    }
</style>