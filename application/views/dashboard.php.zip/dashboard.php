
 
  <!-- Left side column. contains the logo and sidebar -->
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

<?php
 
$dataPoints = array( 
    array("y" => 3373.64, "label" => "Germany" ),
    array("y" => 2435.94, "label" => "France" ),
    array("y" => 1842.55, "label" => "China" ),
    array("y" => 1828.55, "label" => "Russia" ),
    array("y" => 1039.99, "label" => "Switzerland" ),
    array("y" => 765.215, "label" => "Japan" ),
    array("y" => 612.453, "label" => "Netherlands" )
);

// $test=array();
// $count=0;

// $res=$this->db->select('istediyemi');
// while ($row=mysql_fetch_array($res)) {
//   // code...
//   $test["count"]["label"]=$row["std_name"];
//   $test["count"]["y"]=$row["std_level"];
//   $count=$count+1;
// }
 
?>
    <!-- Main content -->
    <section class="content">
 <?php
            if ($this->session->userdata('role') == 1) {
                  ?>
      <div class="row">
        
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab">Home</a></li>
              <li><a href="#timeline" data-toggle="tab">Mullata fi Dudhaalee</a></li>
             
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
                
                <!-- /.post -->

                  <div class="row">
<?php
$cabinota=$this->db->count_all_results('kilabi'); ?>
          <div class="col-md-3 col-sm-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $cabinota?><sup style="font-size: 20px"></sup></h3>

              <p>Kilaboota Ispoortii</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
        <a href="<?php echo base_url('Sport/manageclub') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
          </div>
        </div>
        <!-- /.col -->
       <?php
$doc=$this->db->count_all_results('wirtu'); ?>
          <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green" href="<?php echo base_url('Sport/Marshal_arti') ?>">
            <div class="inner">
              <h3><?php echo $doc?><sup style="font-size: 20px"></sup></h3>

              <p>Wirtuu Maarshal artii</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url('Sport/Marshal_arti') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
          </div>
        </div>
        <!-- ./col -->
  <?php
$user=$this->db->count_all_results('Waldale'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $user?></h3>

              <p>Waldaalee  Ispoortii</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
         <a href="<?php echo base_url('Sport/Waldaalee') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
          <?php
$yada=$this->db->count_all_results('mmi'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $yada?></h3>

              <p>Galii MMI</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="<?php echo base_url('Sport/mmi') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
       </div>
       </div>
       <?php
$yada=$this->db->count_all_results('lenji'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $yada?></h3>

              <p>Lenji Lenjisumma</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="<?php echo base_url('Sport/Leenjisummaa') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
       </div>
       </div>

       <?php
$user=$this->db->count_all_results('olmaisporti'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $user?></h3>

              <p>Bakka Olmaa Ispoortii</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
         <a href="<?php echo base_url('Sport/Oolmaisporti') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

 <?php
$doc=$this->db->count_all_results('gidugala'); ?>
          <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green" href="<?php echo base_url('Sport/Giddugalaleenjii') ?>">
            <div class="inner">
              <h3><?php echo $doc?><sup style="font-size: 20px"></sup></h3>

              <p>Giddugala leenjii</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url('Sport/Giddugalaleenjii') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
          </div>
        </div>
        <!-- ./col -->

        <?php
$cabinota=$this->db->count_all_results('guddattoota'); ?>
          <div class="col-md-3 col-sm-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $cabinota?><sup style="font-size: 20px"></sup></h3>

              <p>Guddattoota</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
        <a href="<?php echo base_url('Sport/Guddattoota') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
          </div>
        </div>

     </div>
                <!-- Post -->
                <div class="post">

                  <div class="user-block">
                    <img class="img-circle img-bordered-sm" src="<?php echo base_url();?>/dist/img/youthlogo.jpg" alt="User Image">
                        <span class="username">
                          <a href="#">Biiroo Dargaggoofi Ispoortii Oromiyaa</a>
                          <a href="#" class="pull-right btn-box-tool"><i class="fa fa-times"></i></a>
                        </span>
                    <span class="description">Damee Ispoortii Oromiyaaa</span>
                  </div>
                  <!-- /.user-block -->
                     <div class="card-body">
<div class="row">
  <?php
$cabinota=$this->db->count_all_results('sgl'); ?>
 
<div class="col-6 col-md-3 text-center">
<div style="display:inline;width:90px;height:90px;"><canvas width="258" height="258" style="width: 90px; height: 90px;"></canvas><input type="text" class="knob" value="<?php echo $cabinota?>" data-skin="tron" data-thickness="0.2" data-width="90" data-height="90" data-fgcolor="#3c8dbc" data-readonly="true" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(60, 141, 188); padding: 0px; appearance: none;"></div>
<div class="knob-label">Buufata SLG</div>
</div>
 <?php
$cabinota=$this->db->count_all_results('gslg'); ?>

<div class="col-6 col-md-3 text-center">
<div style="display:inline;width:90px;height:90px;"><canvas width="258" height="258" style="width: 90px; height: 90px;"></canvas><input type="text" class="knob" value="<?php echo $cabinota?>" data-skin="tron" data-thickness="0.2" data-width="90" data-height="90" data-fgcolor="#3c8dbc" data-readonly="true" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(60, 141, 188); padding: 0px; appearance: none;"></div>
<div class="knob-label">Guddatoota SLG</div>
</div>
<!--  -->
  <?php
$cabinota=$this->db->count_all_results('guddattoota'); ?>

<div class="col-6 col-md-3 text-center">
<div style="display:inline;width:90px;height:90px;"><canvas width="258" height="258" style="width: 90px; height: 90px;"></canvas><input type="text" class="knob" value="<?php echo $cabinota?>" data-skin="tron" data-thickness="0.2" data-width="90" data-height="90" data-fgcolor="#3c8dbc" data-readonly="true" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(60, 141, 188); padding: 0px; appearance: none;"></div>
<div class="knob-label">Baayyina Atileetotaa</div>
</div>
  <?php
$cabinota=$this->db->count_all_results('inisheetivii'); ?>

<div class="col-6 col-md-3 text-center">
<div style="display:inline;width:90px;height:90px;"><canvas width="258" height="258" style="width: 90px; height: 90px;"></canvas><input type="text" class="knob" value="<?php echo $cabinota?>" data-skin="tron" data-thickness="0.2" data-width="90" data-height="90" data-fgcolor="#3c8dbc" data-readonly="true" readonly="readonly" style="width: 49px; height: 30px; position: absolute; vertical-align: middle; margin-top: 30px; margin-left: -69px; border: 0px; background: none; font: bold 18px Arial; text-align: center; color: rgb(60, 141, 188); padding: 0px; appearance: none;"></div>
<div class="knob-label">Inisheetivii</div>
</div>


<!-- <div class="row margin-bottom">
                    <div class="col-sm-12">

<br />
  <h3 align="center"></h3>
  <br />
  <div class="panel panel-default">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-md-9">
                        <h3 class="panel-title">Istediyemiwwaan Oromiyaa keessatti argaman Sadarkaa Isaani Giraafiin</h3>
                    </div>
                    <div class="col-md-3">
                        <select name="bhojetame" id="bhojetame" class="form-control">
                            <option value="">Select Year</option>
                        <?php
                        foreach($year_list->result_array() as $row)
                        {
                            echo '<option value="'.$row["bhojetame"].'">'.$row["bhojetame"].'</option>';
                        }
                        ?>

                        </select>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div id="chart_area" style="width: 900px; height: 520px;"></div>
            </div>
        </div>


</div>

</div>
         -->          
                      
                    </div>
                  

                  </div>
                  <!-- /.row -->

                  
                </div>
                <!-- /.post -->
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="timeline">
                <!-- The timeline -->
                        <ul class="timeline timeline-inverse">
                  <!-- timeline time label -->
                  
                  <!-- /.timeline-label -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-wifi bg-blue"></i>

                    <div class="timeline-item">
                     

                      <h3 class="timeline-header"><a href="#">Mullata Biiroo Dargaggoo fi Ispoortii Oromiyaa</a> </h3>

                      <div class="timeline-body">
                      div class="timeline-body">
                        <b>Mullata:</b>  Bara 2022tti misooma Dargaggoo fi Ispoortii mirkaneessuun biyya keenya badhaadhinatti ceetee arguu dha.
Ergama 
• Dargaggoota naannoo Oromiyaa Bifa Qinda’ee fi gurmaa’een Sochii Ijaarsa Sirna Dimookiraasii, Bulchiinsa Gaarii fi Misoomaa Keessatti Miira Guutuu fi Adda durummaann hirmaatotaa fi fayyadamoo akka ta’an taasisuu
• Ispoortii sochii fi hirmaannaa ummataan bu’uura ummatummaa akka qabaatu taasisuun misooma ispoortii bu’a qabeessa ta’e akka mirkanaa’u taasisuu dha.
.<br>
                       
                      </div>
                      
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
                  <li>
                    <i class="fa fa-wifi bg-aqua"></i>

                    <div class="timeline-item">
                      
 <h3 class="timeline-header"><a href="#">Dudhaalee (Core Values)</a> </h3>
<div class="timeline-body">
• Itti gaafatamummaa/responsibility/ <br>
• Hirmaachisummaa(Participation) <br>
• Iftoomina (Transparency) <br>
• Haqummaa fi hunda-galeessummaa/Equity and inclusiveness/ <br>
• Waliigaltee irra gahuu (Consensus)  <br>
• Olaantummaa seeraa kabajuu(Rule of Law) <br>
• Deebii hatattamaa kennuu (Responsiveness )<br>
• Ga’umsa fi Bu’a qabeessummaa (Effectiveness and Efficiency) <br>
• Aadaa fi Duudhaa Hawaasaa Kabajuu<br>
• Miira tajaajiltummaa ummataa qabaabchuu <br>
• Beekumsaa fi amantaan hogganuu<br>
 <br>
                        1.2.  Aangoo fi gahee Biiroo Dargaggoofi Ispoortii Oromiyaa
Labsii Lakk 242/2015: Labsii qaammota raawwachiistuu Mootummaa Naanno Oromiyaa irra deebiidhaan gurmeessuuf aangoo fi Hojii isaanii murteessuuf baheen; aangoo fi gaheen hojii Biiroo Dargaggoota fi Ispoortii Oromiyaa haala armaan gadiitiin tarreeffameera:
.<br>
                      
                    </div>
                  </li>
                  <!-- END timeline item -->
                  <!-- timeline item -->
           <!--        <li>
                    <i class="fa fa-wifi bg-yellow"></i>

                    <div class="timeline-item">
                    

                      <h3 class="timeline-header"><a href="#">Kaayyoo</a> </h3>

                      <div class="timeline-body">
                        <b>Tokkummaa_Sab-daneessummaa:</b> refers to all of the resources of a network that make network or internet connectivity, management, business operations and communication possible. Network infrastructure comprises hardware and software, systems and devices, and it enables computing and communication between users, services, applications and processes.<br>
                        Anything involved in the network, from servers to wireless routers, comes together to make up a system’s network infrastructure. Network infrastructure allows for effective communication and service between users, applications, services, devices and so forth.
                      </div>
                      
                    </div>
                  </li>
        -->
                  <!-- END timeline item -->
                  <li>
                    <i class="fa fa-clock-o bg-gray"></i>
                  </li>
                </ul>
              </div>
              <!-- /.tab-pane -->

            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <div class="col-md-3">

          <!-- Profile Image -->
          
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Istediyeemii Oromiyaa</h3>
            </div>
            <!-- /.box-header -->
           
             <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-football"></i></span>
<?php 

$this->db->where('std_level =', '1ffaa');
$query = $this->db->get('istediyemi');
$col= $query->num_rows();

?>
            <div class="info-box-content">
              <span class="info-box-text">Sadarkaa 1ffaa</span>
               <span class="info-box-number"><?php echo $col?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <div class="info-box">
            <span class="info-box-icon bg-orange"><i class="ion ion-ios-football"></i></span>
<?php 

$this->db->where('std_level =', '2ffaa');
$query = $this->db->get('istediyemi');
$col= $query->num_rows();

?>
            <div class="info-box-content">
              <span class="info-box-text">Sadarkaa 2ffaa</span>
               <span class="info-box-number"><?php echo $col?></span>
            </div>
            <!-- /.info-box-content -->
          </div>

<div class="info-box">
            <span class="info-box-icon bg-red"><i class="ion ion-ios-football"></i></span>
<?php 

$this->db->where('std_level =', '3ffaa');
$query = $this->db->get('istediyemi');
$col= $query->num_rows();

?>
            <div class="info-box-content">
              <span class="info-box-text">Sadarkaa 3ffaa</span>
               <span class="info-box-number"><?php echo $col?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
              <hr>

              <strong><i class="fa fa-pencil margin-r-5"></i>Gosoota</strong>

              <p>
                <span class="label label-danger">Damee Naannoo</span>
                <span class="label label-success">Damee Godina</span>
                <span class="label label-info">Damee Aanaa</span>
                </p>

              <hr>

              <strong><i class="fa fa-file-text-o margin-r-5"></i>Naannoo oromiyaa</strong>

              <p>Naannoo oromiyaa keessatti ispoortii bu’uura ummataa akka qabatu gochuun hirmaannaa fi dorgomummaa.</p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      <!-- /.row -->







 <?php
                  } else if ($this->session->userdata('role') == 3) {
                        ?>
     

<div class="row">
        
        <!-- /.col -->
        <div class="col-md-12">
          <div class="nav-tabs-custom">
          <h3 class="box-title"><i class="fa fa-wifi"> Odeeffannoo Walii galaa akka Oromiyaatti Jiran  </i></h3>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
                
                <!-- /.post -->

                  <div class="row">



<?php
$cabinota=$this->db->count_all_results('cabine'); ?>
          <div class="col-md-3 col-sm-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $cabinota?><sup style="font-size: 20px">%</sup></h3>

              <p>Dargaggoota Oromiyaa</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/allinfo') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <!-- /.col -->
       <?php
$doc=$this->db->count_all_results('cabine2'); ?>
          <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green" href="<?php echo base_url('Structure/managecabine2') ?>">
            <div class="inner">
              <h3><?php echo $doc?><sup style="font-size: 20px">%</sup></h3>

              <p>Dokumeentoota</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/managecabine2') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <!-- ./col -->
  <?php
$user=$this->db->count_all_results('useraccount'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $user?></h3>

              <p>Ogeessota Sisteemaa</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/User_list') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <!-- ./col -->
          <?php
$yada=$this->db->count_all_results('ipcomment'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $yada?></h3>

              <p>Yaadota Ka'an</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/manage_ipcomment') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
       </div>
       </div>
     </div>
   </div> </div>
     </div>
   </div>





 <div class="row">
        
        <!-- /.col -->
        <div class="col-md-12">

  <div class="container-fluid">
      <h3 class="box-title"><i class="fa fa-plus-square"> Dargaggoota Aannichaa  </i></h3>
<div class="box box-default">




  <div class="row">
        <div class="col-md-12">
          <div class="overview-wrap">
            
          
          </div>
        </div>
      </div>
        <div class="row">
          <div class="col-md-12">
            <div class="table-responsive table--no-card m-b-30">






      <div class="box-body">
                  <table id="example" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
            <thead  class="thead-success">
                  <tr role="row">
                    <tr>
                    <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('no_menu')?></td>
                    <td rowspan="1" style="text-align: center;">Maqaa Guutuu</td>
                    <td rowspan="1" style="text-align: center;">Umurii</td>
                    <td rowspan="1" style="text-align: center;">Salaa</td>
                    <td colspan="3" style="text-align: center;">Bakka Dhaloota</td>
                    <td rowspan="1" style="text-align: center;">Haala Maati</td>
                    <td colspan="2" style="text-align: center;">Teessoo  Ammaa</td>
                    <td rowspan="1" style="text-align: center;">Bilbilaa</td>  
                    <td colspan="3" style="text-align: center;">Barumsaa</td>
                    <!-- <td colspan="3" style="text-align: center;"><?php echo $this->lang->line('liqidayee_menu')?></td>
                    <td colspan="3" style="text-align: center;"><?php echo $this->lang->line('qusanoargame_menu')?></td>
                    <td colspan="3" style="text-align: center;"><?php echo $this->lang->line('buhaargamee_menu')?></td> -->
                    <!-- <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('city_menu')?></td> -->
                    <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('action_menu')?></td> 
                    <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('action_menu')?></td> 

                  </tr> 
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 35.733px;" aria-label="Browser: activate to sort column ascending">NO</th>
                        <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 200.733px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Maqaa Guutuu</th>
                        <!-- <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Organization</th> -->
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Umurii</th>
                     <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Saala</th>
                    
                       <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Naannoo</th>
                       <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Godiina</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Aanaa</th>
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Haala</th>

                        <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Godiina</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Aanaa</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Bilbilaa</th>

                          <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Barnoota</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Sadarkaa Barnootaa</th>

                          <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Iddoo itti Barate</th>

                          <!-- <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Gosa Barumsaa</th> -->

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Haala Fayyaa</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Hala hojii</th>
                        <!-- <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Godiina/Magaala</th>
                         <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 170.733px;" aria-label="Browser: activate to sort column ascending">Aanaa</th>
 -->
                         <!-- <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 200.417px;" aria-label="CSS grade: activate to sort column ascending">Action</th> -->  </tr>
            </thead>

                 <tbody>
                  <?php
                  $no = 0;
             
                        foreach ($this->str->getYouthInfo() as $row) {
                        $no++;
                        ?>
                        <tr role="row" class="odd">
                               <td ><?php echo $no; ?></td>
                              <td><?php echo $row->maqa; ?></td>
                              <td><?php echo $row->age_id; ?></td>
                              <td><?php echo $row->gender_name; ?></td>
                              <td><?php echo $row->r_name; ?></td>
                              <td><?php echo $row->zname; ?></td>
                              <td><?php echo $row->woreda_name; ?></td>
                              <td><?php echo $row->haala; ?></td>
                              <td><?php echo $row->zname1; ?></td>
                              <td><?php echo $row->woreda1_name; ?></td>

                              <td><?php echo $row->lakk_bilbilaa; ?></td>
                              <td><?php echo $row->sd_name; ?></td>
                              <td><?php echo $row->school_name; ?></td>
                              <td><?php echo $row->place_name; ?></td>
                              <!-- <td><?php echo $row->u_name; ?></td> -->
                              <td><?php echo $row->t_name; ?></td>
                              <td><?php echo $row->j_name; ?></td>
                              <!-- <td><?php echo $row->zname; ?></td>
                              <td><?php echo $row->woreda_name; ?></td> -->
                              
                              <!-- <td><?php echo $row->lakk_bilbilaa; ?></td> -->
                      
                            

                               <?php }

                ?>

              </tr>
                   </tbody>
                 </table>
</div>
</div>
</div>
</div>





                        <?php
                  } else if ($this->session->userdata('role') == 2) {
                        ?>

                        <?php
                  } else if ($this->session->userdata('role') == 4) {
                        ?>

<div class="row">
        
        <!-- /.col -->
        <div class="col-md-12">
          <div class="nav-tabs-custom">
          <h3 class="box-title"><i class="fa fa-wifi"> Odeeffannoo Walii galaa akka Oromiyaatti Jiran  </i></h3>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
                
                <!-- /.post -->

                  <div class="row">



<?php
$cabinota=$this->db->count_all_results('cabine'); ?>
          <div class="col-md-3 col-sm-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $cabinota?><sup style="font-size: 20px">%</sup></h3>

              <p>Dargaggoota Oromiyaa</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/allinfo') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <!-- /.col -->
       <?php
$doc=$this->db->count_all_results('cabine2'); ?>
          <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green" href="<?php echo base_url('Structure/managecabine2') ?>">
            <div class="inner">
              <h3><?php echo $doc?><sup style="font-size: 20px">%</sup></h3>

              <p>Dokumeentoota</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/managecabine2') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <!-- ./col -->
  <?php
$user=$this->db->count_all_results('useraccount'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $user?></h3>

              <p>Ogeessota Sisteemaa</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/User_list') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <!-- ./col -->
          <?php
$yada=$this->db->count_all_results('ipcomment'); ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $yada?></h3>

              <p>Yaadota Ka'an</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <!-- <a href="<?php echo base_url('Structure/manage_ipcomment') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
       </div>
       </div>
     </div>
   </div> </div>
     </div>
   </div>






 <div class="row">
        
        <!-- /.col -->
        <div class="col-md-12">

  <div class="container-fluid">
      <h3 class="box-title"><i class="fa fa-plus-square"> Dargaggoota Godinichaa  </i></h3>
<div class="box box-default">


  <div class="row">
        <div class="col-md-12">
          <div class="overview-wrap">
            
          
          </div>
        </div>
      </div>
        <div class="row">
          <div class="col-md-12">
            <div class="table-responsive table--no-card m-b-30">




      <div class="box-body">
            <table id="example" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
            <thead  class="thead-success">
                  <tr role="row">
                    <tr>
                    <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('no_menu')?></td>
                    <td rowspan="1" style="text-align: center;">Maqaa Guutuu</td>
                    <td rowspan="1" style="text-align: center;">Umurii</td>
                    <td rowspan="1" style="text-align: center;">Salaa</td>
                    <td colspan="3" style="text-align: center;">Bakka Dhaloota</td>
                    <td rowspan="1" style="text-align: center;">Haala Maati</td>
                    <td colspan="2" style="text-align: center;">Teessoo  Ammaa</td>
                    <td rowspan="1" style="text-align: center;">Bilbilaa</td>  
                    <td colspan="4" style="text-align: center;">Barumsaa</td>
                    <!-- <td colspan="3" style="text-align: center;"><?php echo $this->lang->line('liqidayee_menu')?></td>
                    <td colspan="3" style="text-align: center;"><?php echo $this->lang->line('qusanoargame_menu')?></td>
                    <td colspan="3" style="text-align: center;"><?php echo $this->lang->line('buhaargamee_menu')?></td> -->
                    <!-- <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('city_menu')?></td> -->
                    <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('action_menu')?></td> 
                    <td rowspan="1" style="text-align: center;"><?php echo $this->lang->line('action_menu')?></td> 

                  </tr> 
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 35.733px;" aria-label="Browser: activate to sort column ascending">NO</th>
                        <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 200.733px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Maqaa Guutuu</th>
                        <!-- <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Organization</th> -->
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Umurii</th>
                     <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Saala</th>
                    
                       <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Naannoo</th>
                       <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Godiina</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Aanaa</th>
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Haala</th>

                        <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Godiina</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Aanaa</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Bilbilaa</th>

                          <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Barnoota</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Sadarkaa Barnootaa</th>

                          <th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.95px;" aria-sort="ascending" aria-label="Rendering engine: activate to sort column descending">Iddoo itti Barate</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 156.217px;" aria-label="Engine version: activate to sort column ascending">Gosa Barumsaa</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Haala Fayyaa</th>

                          <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Hala hojii</th>
                        <!-- <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 100.733px;" aria-label="Browser: activate to sort column ascending">Godiina/Magaala</th>
                         <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 170.733px;" aria-label="Browser: activate to sort column ascending">Aanaa</th>
 -->
                         <!-- <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 200.417px;" aria-label="CSS grade: activate to sort column ascending">Action</th> -->  </tr>
            </thead>

                 <tbody>
                  <?php
                  $no = 0;
             
                        foreach ($this->str->getYouthInfo() as $row) {
                        $no++;
                        ?>
                        <tr role="row" class="odd">
                               <td ><?php echo $no; ?></td>
                              <td><?php echo $row->maqa; ?></td>
                              <td><?php echo $row->age_id; ?></td>
                              <td><?php echo $row->gender_name; ?></td>
                              <td><?php echo $row->r_name; ?></td>
                              <td><?php echo $row->zname; ?></td>
                              <td><?php echo $row->woreda_name; ?></td>
                              <td><?php echo $row->haala; ?></td>
                              <td><?php echo $row->zname1; ?></td>
                              <td><?php echo $row->woreda1_name; ?></td>

                              <td><?php echo $row->lakk_bilbilaa; ?></td>
                              <td><?php echo $row->sd_name; ?></td>
                              <td><?php echo $row->school_name; ?></td>
                              <td><?php echo $row->place_name; ?></td>
                              <td><?php echo $row->u_name; ?></td>
                              <td><?php echo $row->t_name; ?></td>
                              <td><?php echo $row->j_name; ?></td>
                              <!-- <td><?php echo $row->zname; ?></td>
                              <td><?php echo $row->woreda_name; ?></td> -->
                              
                              <!-- <td><?php echo $row->lakk_bilbilaa; ?></td> -->
                      
                            

                               <?php }

                ?>

              </tr>
                   </tbody>
                 </table>
</div>
</div>
</div>
</div>



<?php } ?>


    </section>




    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

<!-- ./wrapper -->



<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">

google.charts.load('current', {packages:['corechart', 'bar']});
google.charts.setOnLoadCallback();

function load_monthwise_data(bhojetame, title)
{
    var temp_title = title + ' ' + bhojetame;
    $.ajax({
        url:"<?php echo base_url(); ?>dynamic_chart/fetch_data",
        method:"POST",
        data:{bhojetame:bhojetame},
        dataType:"JSON",
        success:function(data)
        {
            drawMonthwiseChart(data, temp_title);
        }
    })
}

function drawMonthwiseChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data = new google.visualization.DataTable();
    data.addColumn('string', 'std_name');
    data.addColumn('number', 'std_level');

    $.each(jsonData, function(i, jsonData){
        var std_name = jsonData.std_name;
        var std_level = parseFloat($.trim(jsonData.std_level));
        data.addRows([[std_name, std_level]]);
    });

    var options = {
        title:chart_main_title,
        hAxis: {
            title: "Maqaa Istediyemii"
        },
        vAxis: {
            title: 'Sadarkaa'
        },
        chartArea:{width:'70%',height:'30%'}
    }

    var chart = new google.visualization.ColumnChart(document.getElementById('chart_area'));

    chart.draw(data, options);
}

</script>

<script>
    
$(document).ready(function(){
    $('#bhojetame').change(function(){
        var bhojetame = $(this).val();
        if(bhojetame != '')
        {
            load_monthwise_data(bhojetame, 'Istediyemiwwaan Oromiyaa keessatti argaman Sadarkaa Isaani');
        }
    });
});

</script>




<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
    theme: "light2",
    title:{
        text: "Gold Reserves"
    },
    axisY: {
        title: "Gold Reserves (in tonnes)"
    },
    data: [{
        type: "column",
        yValueFormatString: "#,##0.## tonnes",
        dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
    }]
});
chart.render();
 
}
</script>


<!-- jQuery 3 -->
<script type="text/javascript">

      $(document).ready(function () {
            $("#zone").change(function () {
                  var zid = $("#zone").val();
                  $.ajax({
                        url: '<?php echo base_url(); ?>BDDDDOcontroller/getWoreda',
                        'method': 'post',
                        'data': {zid: zid},
                        'type': 'JSON'
                  }).done(function (woreda) {
                        console.log(woreda);
                        town = JSON.parse(woreda);
                        $("#woreda").empty();
                        town.forEach(function (woreda) {
                              $("#woreda").append('<option value=' + woreda.woreda_id + '>' + woreda.woreda_name + '</option>');
                        });
                  });
            });

      });
</script>  
<script>
      $(document).ready(function () {
            $('#example').DataTable({
                  dom: 'lBfrtip',
                  buttons: [
                        'copy', 'csv', 'excel', 'pdf', 'print'
                  ]
            });
      });
</script>

